import { DynamoDBClient, ExecuteStatementCommand, ExecuteTransactionCommand } from "@aws-sdk/client-dynamodb";
import { unmarshall } from "@aws-sdk/util-dynamodb";
import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";
import axios from 'axios';

const dbClient = new DynamoDBClient({ region: process.env.AWS_REGION });
const snsClient = new SNSClient({ region: process.env.AWS_REGION });

async function fetchAllRecords(sql) {
    let results = [];
    let nextToken;

    do {
        const command = new ExecuteStatementCommand({
            Statement: sql,
            NextToken: nextToken, // Add NextToken if available
        });

        const response = await dbClient.send(command);

        // Accumulate items from this page
        if (response.Items) {
            results = results.concat(response.Items);
        }

        // Update nextToken for the next iteration
        nextToken = response.NextToken;
    } while (nextToken); // Continue until there's no nextToken

    return results;
}


export const handler = async (event) => {
    // console.log("nft dequeue mint event", event);
    
    let tableName;

    try {
        
        var headers = event.headers;
        var body = {};

        if(event.body)
            body = JSON.parse(event.body);

        // console.log("origin", headers['origin']);
        tableName = process.env.TABLE_NAME_COMMUNITY;
        if((!headers['origin'].includes("anifie.community.admin") && !headers['origin'].includes("honda-synergy-lab.jp") && !headers['origin'].includes("anifie.com") && !headers['origin'].includes("global.honda")) || (headers['origin'].includes("anifie.communitytest.admin.s3-website-ap-northeast-1.amazonaws.com"))) {
            tableName = process.env.TABLE_NAME_COMMUNITY_TEST;
        }
        console.log("tableName", tableName);

        let sql = `select * from "${tableName}" where PK = 'POINT_SETTINGS' and SK = 'POINT_SETTINGS'`;
        let pointSettingsResult = await fetchAllRecords(sql);
        let pointSettings = pointSettingsResult.map(unmarshall)[0];

        sql = `select * from "${tableName}"."ByTypeCreatedDate" where type = 'MEMBER' and discord_user_id is not missing`;
        let membersResult = await fetchAllRecords(sql);
        let members = membersResult.map(unmarshall);

        // let txStatements = [];
        let membersPoints = [];

        for (let i = 0; i < members.length; i++) {

            const member = members[i];
            console.log("member", member);
            
            // messages
            sql = `select * from "${tableName}"."ByTypeCreatedDate" where type = 'DISCORD_MESSAGE' and discord_user_id = '${member.discord_user_id}'`;
            let messagesResult = await fetchAllRecords(sql);
            let messages = messagesResult.map(unmarshall);

            // reactions
            sql = `select * from "${tableName}"."ByTypeCreatedDate" where type = 'DISCORD_REACTION' and discord_user_id = '${member.discord_user_id}'`;
            let reactionsResult = await fetchAllRecords(sql);
            let reactions = reactionsResult.map(unmarshall);

            // votes
            sql = `select * from "${tableName}"."ByTypeCreatedDate" where type = 'VOTE_DISCORD_ANSWER' and SK = '${member.discord_user_id}'`;
            let votesResult = await fetchAllRecords(sql);
            let votes = votesResult.map(unmarshall);

            // roles
            sql = `select * from "${tableName}" where SK = 'DISCORD_USER' and PK = 'DISCORD_USER#${member.discord_user_id}'`;
            let userResult = await fetchAllRecords(sql);
            let user = userResult.map(unmarshall)[0];
            if(user.roles){
                user.roles = user.roles.split(',');
            }

            let totalPoints = (pointSettings.WeightMessage * messages.length) 
                                + (pointSettings.WeightReaction * reactions.length) 
                                + (pointSettings.WeightVote * votes.length);

            if(user.roles && pointSettings.WeightRole) {
                for (let i = 0; i < pointSettings.WeightRole.length; i++) {
                    const weightRole = pointSettings.WeightRole[i];
                    
                    if(user.roles.includes(weightRole.role)) {
                        totalPoints += weightRole.weight;
                    }
                }
            }

            sql = `UPDATE "${tableName}" 
                    SET modified_date = '${new Date().toISOString()}' 
                    , total_points = ${totalPoints}
                    WHERE PK = '${member.PK}' AND SK = '${member.SK}'`;

            let updateResult = await dbClient.send(new ExecuteStatementCommand({ Statement: sql }));
            console.log("updateResult", updateResult);

            // txStatements.push({ "Statement": sql});

            // const statements = { "TransactStatements": txStatements };  
            // console.log("statements", JSON.stringify(statements));
            // const dbTxResult = await dbClient.send(new ExecuteTransactionCommand(statements));
            // console.log("Transaction result", dbTxResult);

            membersPoints.push({ 
                                    member: member, 
                                    total_points: totalPoints, 
                                    messages_count: messages.length, 
                                    reactions_count: reactions.length, 
                                    votes_count: votes.length,
                                    roles: user.roles,
                                    discord_user_name: user.username,
                                    discord_user_avatar: user.avatar,
                                    discord_user_discriminator: user.discriminator,
                                });
        }

        for (let i = 0; i < membersPoints.length; i++) {
            const membersPoint = membersPoints[i];

            for (let level = 1; level <= 1000; level++) {
                
                const levelMaxPoints = 15 * Math.pow(level, 2) + (50 * level);

                if(membersPoint.total_points <= levelMaxPoints) {
                    membersPoint.level = level;
                    membersPoint.pointsRequiredToNextLevel = levelMaxPoints - membersPoint.total_points;
                    break;
                }
            }
            
            if(membersPoint.level == undefined) {
                membersPoint.level = 1000;
                membersPoint.pointsRequiredToNextLevel = 0;
            }
        }

        membersPoints.sort((a, b) => b.total_points - a.total_points);  // descending order

        sql = `select * from "${tableName}"."ByTypeCreatedDate" where type = 'LEADERBOARD'`;
        let leaderboardResult = await fetchAllRecords(sql);
        if(leaderboardResult.length > 0) {
            for (let i = 0; i < leaderboardResult.length; i++) {
                const leaderBoard = leaderboardResult[i];
                sql = `DELETE FROM "${tableName}" WHERE PK = '${leaderBoard.PK}' AND SK = '${leaderBoard.SK}'`;
                await dbClient.send(new ExecuteStatementCommand({ Statement: sql }));
            }
        }

        console.log("membersPoints", membersPoints);

        for (let i = 0; i < membersPoints.length; i++) {
            const membersPoint = membersPoints[i];
            sql = `INSERT INTO "${tableName}" 
                    VALUE { 
                        'PK': 'LEADERBOARD#${i + 1}' , 
                        'SK': '${membersPoint.member.discord_user_id}', 
                        'type': 'LEADERBOARD', 
                        'discord_user_id': '${membersPoint.member.discord_user_id}', 
                        'discord_user_avatar': '${membersPoint.member.discord_user_avatar ? membersPoint.member.discord_user_avatar : ''}', 
                        'discord_user_discriminator': '${membersPoint.member.discord_user_discriminator}',
                        'discord_user_name': '${membersPoint.member.discord_user_name ? membersPoint.member.discord_user_name : ''}', 
                        'user_id': '${membersPoint.member.user_id}', 
                        'wallet_address': '${membersPoint.member.wallet_address}', 
                        'level': ${membersPoint.level}, 
                        'total_points': ${membersPoint.total_points}, 
                        'messages_count': ${membersPoint.messages_count}, 
                        'reactions_count': ${membersPoint.reactions_count}, 
                        'votes_count': ${membersPoint.votes_count}, 
                        'roles': '${membersPoint.roles && membersPoint.roles.length > 0 ? JSON.stringify(membersPoint.roles) : ''}', 
                        'points_required_to_next_level': ${membersPoint.pointsRequiredToNextLevel},
                        'rank': ${i + 1},
                        'created_date': '${new Date().toISOString()}'
                    }`;

            console.log("sql", sql);
            let insertResult = await dbClient.send(new ExecuteStatementCommand({ Statement: sql }));
            console.log("insertResult", insertResult);

        }
        
        return {
            Success: true
        }
        
    } catch (e) {
        const random10DigitNumber = Math.floor(Math.random() * 9000000000) + 1000000000;

        console.error('error in comm-point-award-post ' + random10DigitNumber, e);
        
        const message = {
            Subject: 'Honda Error - comm-point-award-post - ' + random10DigitNumber,
            Message: `Error in comm-point-award-post: ${e.message}\n\nStack trace:\n${e.stack}`,
            TopicArn: process.env.SNS_TOPIC_ERROR
        };
        
        // if(tableName == process.env.TABLE_NAME_COMMUNITY)
        //     await snsClient.send(new PublishCommand(message));
        
        const response = {
            Success: false,
            Message: e.message
            //Message: 'エラーが発生しました。管理者に連絡してください。Code: ' + random10DigitNumber
        };
        
        return response;
    }
    
};