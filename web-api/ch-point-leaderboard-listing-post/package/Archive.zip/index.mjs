import { DynamoDBClient, ExecuteStatementCommand, PutItemCommand } from "@aws-sdk/client-dynamodb";
import { unmarshall } from "@aws-sdk/util-dynamodb";
import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";
import { LambdaClient, InvokeCommand } from "@aws-sdk/client-lambda";
import axios from 'axios';

// Initialize clients
const dbClient = new DynamoDBClient({ region: process.env.AWS_REGION });
const snsClient = new SNSClient({ region: process.env.AWS_REGION });

function toLeaderBoard(obj) {
    return {
        MemberId: obj.user_id,
        DiscordUserId: obj.discord_user_id,
        WalletAddress: obj.wallet_address,
        Level: obj.level,
        TotalPoints: obj.points,
        MessagesCount: obj.messages_count,
        ReactionsCount: obj.reactions_count,
        VotesCount: obj.votes_count,
        Roles: obj.roles && obj.roles.length > 0 ? JSON.parse(obj.roles) : undefined,
        PointsRequiredToNextLevel: obj.points_required_to_next_level,
        Rank: obj.rank,
        CreatedDate: obj.created_date,
    }
}

export const handler = async (event) => {
    // console.log("nft dequeue mint event", event);
    
    let tableName;

    try {
        
        var headers = event.headers;
        var body = {};

        if(event.body)
            body = JSON.parse(event.body);

        console.log("origin", headers['origin']);
        tableName = process.env.TABLE_NAME_COMMUNITY;
        if((!headers['origin'].includes("anifie.community.admin") && !headers['origin'].includes("honda-synergy-lab.jp") && !headers['origin'].includes("anifie.com") && !headers['origin'].includes("global.honda")) || (headers['origin'].includes("anifie.communitytest.admin.s3-website-ap-northeast-1.amazonaws.com"))) {
            tableName = process.env.TABLE_NAME_COMMUNITY_TEST;
        }
        console.log("tableName", tableName);

        let sql = `select * from "${tableName}"."ByTypeCreatedDate" where type = 'LEADERBOARD' order by created_date desc`;
        if(body.discordUserId) {
            sql = `select * from "${tableName}"."InvertedIndex" where type = 'LEADERBOARD' and SK = '${body.discordUserId}'`;
        }

        console.log("sql", sql);

        let leaderboardsResult = await dbClient.send(new ExecuteStatementCommand({ Statement: sql }));
        let leaderBoards = leaderboardsResult.Items.map(unmarshall);

        return {
            Success: true,
            Data: leaderBoards.map(x => toLeaderBoard(x))
        }
        
    } catch (e) {
        const random10DigitNumber = Math.floor(Math.random() * 9000000000) + 1000000000;

        console.error('error in comm-point-leaderboard-listing-post ' + random10DigitNumber, e);
        
        const message = {
            Subject: 'Honda Error - comm-point-leaderboard-listing-post - ' + random10DigitNumber,
            Message: `Error in comm-point-leaderboard-listing-post: ${e.message}\n\nStack trace:\n${e.stack}`,
            TopicArn: process.env.SNS_TOPIC_ERROR
        };
        
        if(tableName == process.env.TABLE_NAME_COMMUNITY)
             await snsClient.send(new PublishCommand(message));
        
        const response = {
            Success: false,
            Message: e.message
            //Message: 'エラーが発生しました。管理者に連絡してください。Code: ' + random10DigitNumber
        };
        
        return response;
    }
    
};